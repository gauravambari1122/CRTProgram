// given no is even or odd
#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	if (a%2==0)
		printf("even number");
	else
		printf("odd number");
	return 0;
}
