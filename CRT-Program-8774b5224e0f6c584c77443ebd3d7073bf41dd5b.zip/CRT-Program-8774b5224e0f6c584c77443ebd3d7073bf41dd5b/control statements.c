control statements:(selective statements)
(decision making statements):
1)simple if statement
2)if else statement
3)netsed if else statement
4)else if ladder
5)switch statement
1)
if (exp)
statement;
or
if(exp)
{
st1;
st2;
.......stn;
}
2)
if(exp)
true-block-statements;
else
false-block-statements;
3)
if(exp1)
{
if(exp2)
st1;
else
st2;
}
else
st3;
4)
if(exp1)
st1;
else if(exp2)
st2;
else if(exp3)
st3;
else
st4;
5)
switch(exp)
{
case exp1:
st1;
break;
case exp2:
st2;
.......
.......
....
case expn:
stn;
break;
default:
stx;
break;
}
