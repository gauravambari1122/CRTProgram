#include<stdio.h>
int main()
{
int a;
float b;
char c;
printf("\n%d=",sizeof(a));
printf("\n%d=",sizeof(b));
printf("\n%d=",sizeof(c));
	return 0;
}
