operators:
	1)arithmetic ops:
		+,-,*,/ and %
	a=10,b=3;
	a/b=3
	a%b=1
	 2)a=1947
	 a%10=7
	 a/10=194
	 2)logical ops
	 	and &&
	 	or	||
	 	not	!
exp1	exp2	exp1&&exp2	exp1||exp2	!exp1
T		T			T			T			F
T		F			F			T			F
F		T			F			T			T
F		F			F			F			T
3) Relational ops:
< <= > >= == !=
4) Assignment Ops:
=
+=,-=,*=,/=,%=  //compound assignments
a+=b----->a=a+b
5)sizeof()
used to find the size of datatype/literals/variables
6) Conditional Op or ternary op
syntax: ex1?exp2:exp3;
---
if(exp1)
exp2;
else
exp3;
7)increment/decrement ops
a=10;
++a --//pre increment
a++ --//post increment
--a==//pre decrement
a-- //post decrement

8)bit wise ops

& and
| or
^ xor
~ complement
<< leftshift
>> rightshift

a b a&b a|b a^b
0 0  0	 0	 0
0 1	 0	 1	 1
1 0	 0	 1	 1
1 1	 1	 1	 0
9) comma (,)

