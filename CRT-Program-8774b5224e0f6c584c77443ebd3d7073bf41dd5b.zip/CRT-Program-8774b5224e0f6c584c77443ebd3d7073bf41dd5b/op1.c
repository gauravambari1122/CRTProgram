#include<stdio.h>
int main()
{
printf("\n%d",sizeof(12));
printf("\n%d",sizeof(12.5));
printf("\n%d",sizeof('a'));
printf("\n%d",sizeof(12.5f));
	return 0;
}
