#include<stdio.h>
int main()
{
int a=10;
printf("\na=%d",a);
printf("\na++=%d",a++);
printf("\na=%d",a);
	return 0;
}
