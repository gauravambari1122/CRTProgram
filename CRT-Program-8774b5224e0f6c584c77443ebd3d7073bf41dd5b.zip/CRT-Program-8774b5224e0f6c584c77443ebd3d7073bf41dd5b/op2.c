#include<stdio.h>
int main()
{
int a=100,b=30,c;
c=a>b?a:b;
printf("the biggest no is:%d",c);
	return 0;
}
